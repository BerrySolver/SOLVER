-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: i5a507.p.ssafy.io    Database: solver
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` varchar(255) NOT NULL,
  `content` longtext,
  `reg_dt` datetime(6) DEFAULT NULL,
  `answer_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdqc83j2n6hemidegfkim17d3l` (`answer_id`),
  KEY `FK8kcum44fvpupyw6f5baccx25c` (`user_id`),
  CONSTRAINT `FK8kcum44fvpupyw6f5baccx25c` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKdqc83j2n6hemidegfkim17d3l` FOREIGN KEY (`answer_id`) REFERENCES `answer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES ('4KUi0af3xhFDB','저야말로 감사합니다','2021-08-20 04:07:11.829000','N6IaeP6v2XH8C','W9kYunNrx8XLa'),('9UWxG5MXmEZHl','정말 유용한 정보네요!','2021-08-20 03:47:10.451000','N6IaeP6v2XH8C','vtBU6MkAFjMjZ'),('DykBkOY0kukxc','감사합니다 ㅎㅎ 채택 드리겠습니다!','2021-08-20 03:46:51.883000','N6IaeP6v2XH8C','6Yrfp6KX9LPRL'),('ePgGsl3ZWxtfd','헉 그 유명한 조현민 강사님이시군요!! 화상신청 드리겠습니다!!!','2021-08-20 05:59:36.517000','OuCTFLWXBtHcU','JIujzT9QJaA3c'),('jGAvUTv6Q5dts','오! 해결했어요 현민님 카톡잘알이시군요 ^-^','2021-08-20 03:43:27.368000','hNJ8kOHE0Jwvy','W9kYunNrx8XLa'),('LmZNmhE9Iq8GR','오호....그래도 이번엔 Vue.js로 도전해봐야겠네요 답변 감사합니다~~','2021-08-20 03:44:18.829000','zbkkSV91Vrnyn','W9kYunNrx8XLa'),('So0Wdv2GuHrXf','ㅋㅋㅋㅋㅋㅋ이거였어요!!! 오늘부터 매일 이것만 들을래요 ㅎㅎ 감사합니다~','2021-08-20 03:53:07.419000','XWFZzF0uuEspN','W9kYunNrx8XLa'),('ThgebL7GbOblJ','감사합니다! 직접 코칭 받고싶네요~ㅜㅜ','2021-08-20 05:53:40.019000','nfZcSio7Dwwk6','JIujzT9QJaA3c'),('tMYWgvM8ibr5m','우와! 빠른 답변 감사합니다ㅎㅎ 덕분에 과제도 잘 마무리했어요 :D','2021-08-20 03:30:30.418000','mlrnoWMzl8w6T','W9kYunNrx8XLa');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  7:37:19
