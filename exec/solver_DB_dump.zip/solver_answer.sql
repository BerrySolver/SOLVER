-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: i5a507.p.ssafy.io    Database: solver
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answer` (
  `id` varchar(255) NOT NULL,
  `content` longtext,
  `reg_dt` datetime(6) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `question_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9wpd737ddaj5qed1mnuppf8ku` (`type`),
  KEY `FK8frr4bcabmmeyyu60qt7iiblo` (`question_id`),
  KEY `FK68tbcw6bunvfjaoscaj851xpb` (`user_id`),
  CONSTRAINT `FK68tbcw6bunvfjaoscaj851xpb` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK8frr4bcabmmeyyu60qt7iiblo` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`),
  CONSTRAINT `FK9wpd737ddaj5qed1mnuppf8ku` FOREIGN KEY (`type`) REFERENCES `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES ('22Q69X7yHMZGw','<p>영상 편집에 사용되는 다양한 프로그램이 있는데요</p><p>대표적으로 어도비프리미어프로, 베가스, 윈도우무비메이커 등이 있습니다.</p><p>&nbsp;</p><p>그 중에서는 어도비 프리미어 프로가 가장 많이 사용되는 프로그램인 것 같아요!</p><p>다만 조금 어려울 수 있어서 유튜브 강의도 찾아보시는 것을 추천드립니다.</p>','2021-08-20 04:10:22.048000','050','R8AiGyMOzrNwz','W9kYunNrx8XLa'),('2JKEGFO8Ns8Bl','<video data-v-6746ab92=\"\" controls name=\"media\"  width=\"800px\" height=\"600px\"><source data-v-6746ab92=\"\" src=\"https://solver-bucket.s3.ap-northeast-2.amazonaws.com/f612a41c-b44f-480a-ab7b-19de3afd1e3e.mp4\" type=\"video/mp4\"></video>','2021-08-20 04:43:40.113000','051','n7N3t3WF417Gi','vtBU6MkAFjMjZ'),('7RfgiSGjrYg7k','<p>(631642 x 51829023) / (8537000 x 8537000) 으로 계산하시면 돼요~</p><p>&nbsp;</p><p>계산하면 약 0.0449 네요 ㅎㅎ</p>','2021-08-20 03:57:08.242000','050','QqqcCmEsbeqr2','W9kYunNrx8XLa'),('cUerDurZN22le','<p>조금은 느린 속도(?) 같은 성능을 일반적 방법으로 개발한 것보다 vue js가 더 느릴 수 있습니다 하지만, 대부분의 유저들 기기 성능이 좋기에 큰 문제가 되지 않습니다.&nbsp;</p>','2021-08-20 03:44:02.259000','050','n7N3t3WF417Gi','vtBU6MkAFjMjZ'),('fA7LGdxaUFEXg','<p>폰트가 문제일 수 있습니다.&nbsp;</p><p>사용하고 계신 폰트 내에서 숫자나 괄호의 앞뒤 여백이 약간 넓게 설정되어 있어서 그렇습니다. ​</p><p>&nbsp;아래 구글 폰트의 결과를 보시면 폰트마다 모양뿐만 아니라 간격도 다른것을 알 수 있습니다.</p><p>&nbsp;https://fonts.google.com/?preview.text=4.97(203)&amp;preview.text_type=custom</p>','2021-08-20 04:36:34.776000','050','uA9M73SPEkjOP','6Yrfp6KX9LPRL'),('h2jD477ACgbDv','<video data-v-6746ab92=\"\" controls name=\"media\"  width=\"800px\" height=\"600px\"><source data-v-6746ab92=\"\" src=\"https://solver-bucket.s3.ap-northeast-2.amazonaws.com/423af5a7-62ed-439d-8c20-2767e773602f.mp4\" type=\"video/mp4\"></video>','2021-08-20 06:19:51.743000','051','o4Lf7LAxNx8NO','JIujzT9QJaA3c'),('hNJ8kOHE0Jwvy','<p><strong>카톡 대화방에 들어가셔서요~ 이모티콘 창을 누르시고 고르는 칸을 옆으로 돌리시면 톱니바퀴가 나옵니다. 거기서 순서 정리 하실 수 있으세요.</strong></p>','2021-08-20 03:40:47.221000','052','0VI2NH729KRqY','vtBU6MkAFjMjZ'),('Lj9RHxyYyGHnj','<p>질문이 너무 어렵네요..</p>','2021-08-20 03:36:39.982000','050','vY902AjkrUwAO','vtBU6MkAFjMjZ'),('LT86IQfTCDsVF','<p>과제는 스스로 하셔야 의미가 있어요!</p><p>&nbsp;</p><p>9번 - 4&nbsp;<br>나머지 보기는 ‘~ 해본 적 있다’의 의미로 사용되었습니다.</p><p>10번 - 4&nbsp;<br>~부터</p><p>11번 - 1<br>have + pp 형태로 사용하여야 합니다.</p><p>12번 - 4<br>현재 진행형으로 사용된 점이 잘못되었습니다.</p><p>13번 - 4<br>‘~ 해본 적 있다’의 의미로 사용된 것은 4번 뿐입니다.</p><p>14번 - 4<br>방문했다는 의미라면 been 을 사용해야하고 떠났다는 의미라면 gone을 사용해야합니다.</p><p>15번 - 3<br>그랜드 공원에 가본적있니?<br>응 한번 가봤어</p>','2021-08-20 04:06:56.992000','050','tP6xmPoifx3hr','W9kYunNrx8XLa'),('LXw8y189vYunL','<p>‘말을 걺’이 옳은 표기입니다.&nbsp;</p><p>만들다 &gt; 만듦</p><p>알다 &gt; 앎</p><p>살다 &gt; 삶</p><p>처럼, 어간 끝이 ‘ㄹ’받침인 용언은 어간 뒤에 명사형 어미 ‘-ㅁ’을 붙여 명사형을 만듭니다!</p>','2021-08-20 06:24:49.365000','050','znbVkpCXxlVrT','JIujzT9QJaA3c'),('lZcZEWU86hyJg','<p>잠시 일어나서 허리를 쭉 피는 것도 도움이 많이 됩니다</p>','2021-08-20 05:50:45.271000','050','QVcpnjRGUbcW7','6Yrfp6KX9LPRL'),('mlrnoWMzl8w6T','<p>니혼고 요쿠 와카리마센.</p><p>니혼고노 벵쿄우오 시나레바 나라나이요.</p>','2021-08-20 03:29:44.908000','052','RiQWd1FbZy43n','6Yrfp6KX9LPRL'),('N6IaeP6v2XH8C','<p>안녕하세요 승호님!</p><p>자바와 자바스크립트는 엄연히 다르답니다 ㅎㅎ<br><br>둘 다 객체지향 프로그래밍(OOP)이라는 공통점이 있지만,</p><p>자바는 객체지향 프로그래밍 언어라는 점, 자바스크립트는 웹 프로그래밍을 위한 객체지향 스크립트 언어라는 점에서 차이를 갖습니다!</p><p>&nbsp;</p><p>도움이 되셨다면 채택 부탁드려요?!</p>','2021-08-20 03:37:01.781000','052','bl3nJNKZSkHe3','W9kYunNrx8XLa'),('nfZcSio7Dwwk6','<p>스트레칭 코치 중에</p><p>조현민이라는 분 계시는데</p><p>그분이 정말 잘하시더라구요!</p><p>&nbsp;</p><p>현아님께도 추천드립니다~</p>','2021-08-20 05:49:39.217000','050','QVcpnjRGUbcW7','W9kYunNrx8XLa'),('O9fetUty2jbBL','<p>0.449193496067041</p>','2021-08-20 03:56:47.312000','050','QqqcCmEsbeqr2','vtBU6MkAFjMjZ'),('ocixtN5o8NrvO','<p>개념적이라는 다양한 분류를 이해하고 진행하시면 좋을것같아요!<br>간단하게 영상과 자료를 통해 10분 이내로 화상가능하니 편하신 시간에 원하시면 신청해주세요!</p>','2021-08-20 06:16:36.628000','050','o4Lf7LAxNx8NO','JIujzT9QJaA3c'),('OuCTFLWXBtHcU','<p>스트레칭이 알고싶으신가요?</p>','2021-08-20 05:57:57.022000','052','QVcpnjRGUbcW7','vtBU6MkAFjMjZ'),('S6v5txE7Pt5TM','<p>저도 동일한 오류가 나타납니다. 오리건말고 South Carolina, 그리고 그 외에&nbsp; p100이 있는 지역으로 다 설정을 해서 다시 해보아도 동일한 현상이 일어나네요.&nbsp;</p>','2021-08-20 04:00:37.872000','050','cvh6TY4XnNtgl','6Yrfp6KX9LPRL'),('VKOsj0WQROjJA','<p>X세대는 1970년 전후 베이비 붐 세대에 태어난 세대를, Y세대는 1980~94년 사이에 태어난 세대를, Z세대는 1995년 이후 2000년 중후반까지 태어난 세대를 Z세대라고 부르는데, 세대를 구분하는기준은 명확하지 않습니다. ​ ​ 위 기준에 따르면 2000 ~ 2003년생은 Z세대에 속하고, Z 세대 이후의 세대에 대하여는 아직 불리우는 명칭이 없습니다.&nbsp;</p>','2021-08-20 03:41:33.354000','050','wr2MC9aIs2kVE','vtBU6MkAFjMjZ'),('XWFZzF0uuEspN','<p>빌리 아일리시- bad guy 아닌가요?</p>','2021-08-20 03:45:55.125000','052','o54hTHTU9kkNn','vtBU6MkAFjMjZ'),('zbkkSV91Vrnyn','<p>vue js와 같은 경우 SPA를 만들 때 활용됩니다. 요즘은 React를 많이 쓰고 있지만 아직 Vue도 잘 사용되고 있죠.</p><p>Vue의 장점이라고 하면 쉬운 SPA 구현과 React에 비해 가독성이 높은 코드입니다. 공식문서도 잘 되어있고, 편하게 배우실 수 있으실 거에요.</p><p>다만 단점이라고 하면 SPA를 만들면서 신경써야 하는 부분이 있다는 것과, 다른 프레임워크에 비해 생태계가 적다는 것일 겁니다.</p>','2021-08-20 03:40:56.829000','052','n7N3t3WF417Gi','6Yrfp6KX9LPRL');
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  7:37:15
