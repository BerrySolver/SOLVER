-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: i5a507.p.ssafy.io    Database: solver
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message` (
  `id` varchar(255) NOT NULL,
  `checked` bit(1) NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `question_id` varchar(255) DEFAULT NULL,
  `reg_dt` datetime(6) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `receive_user_id` varchar(255) DEFAULT NULL,
  `send_user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkfx4g8auo9xlf1wc3lcuj55q4` (`type`),
  KEY `FKhgf3w0h82ws01op4d4b8qj4ti` (`receive_user_id`),
  KEY `FK3rg9ilkfcwu7ywo9utiwo4q24` (`send_user_id`),
  CONSTRAINT `FK3rg9ilkfcwu7ywo9utiwo4q24` FOREIGN KEY (`send_user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKhgf3w0h82ws01op4d4b8qj4ti` FOREIGN KEY (`receive_user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKkfx4g8auo9xlf1wc3lcuj55q4` FOREIGN KEY (`type`) REFERENCES `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES ('9cyuJqxIvfPki',_binary '\0','2021-08-20 18:30','QVcpnjRGUbcW7','2021-08-20 06:00:27.212000','075','JIujzT9QJaA3c','vtBU6MkAFjMjZ'),('baf9NjqGQgRdX',_binary '\0','2021-08-20 04:30','n7N3t3WF417Gi','2021-08-20 04:42:51.523000','075','W9kYunNrx8XLa','vtBU6MkAFjMjZ'),('cLhI75OJw0FHg',_binary '\0','2021-08-20 04:30','n7N3t3WF417Gi','2021-08-20 04:42:51.523000','075','vtBU6MkAFjMjZ','W9kYunNrx8XLa'),('cZ2wZQp1PQgjE',_binary '\0','짧고 굵게 바로 진행하겠습니다!','o4Lf7LAxNx8NO','2021-08-20 06:17:51.335000','073','JIujzT9QJaA3c','vtBU6MkAFjMjZ'),('JjYb1s9Sc9ioc',_binary '\0','짧고 굵게 바로 진행하겠습니다!','o4Lf7LAxNx8NO','2021-08-20 06:17:51.335000','073','vtBU6MkAFjMjZ','JIujzT9QJaA3c'),('l7nrmIi9MZmXS',_binary '\0','2021-08-20 10:00','o4Lf7LAxNx8NO','2021-08-20 06:17:51.366000','075','JIujzT9QJaA3c','vtBU6MkAFjMjZ'),('LsXW4jsYO3VFD',_binary '\0','2021-08-20 18:30','QVcpnjRGUbcW7','2021-08-20 06:00:27.212000','075','vtBU6MkAFjMjZ','JIujzT9QJaA3c'),('nUcYLsonChcxN',_binary '','2021-08-20 10:00','o4Lf7LAxNx8NO','2021-08-20 06:17:04.356000','072','JIujzT9QJaA3c','vtBU6MkAFjMjZ'),('PLiX8VzGja39B',_binary '','2021-08-20 04:30','n7N3t3WF417Gi','2021-08-20 04:42:34.634000','072','vtBU6MkAFjMjZ','W9kYunNrx8XLa'),('PODN1v8Bqy5X0',_binary '\0','2021-08-20 10:00','o4Lf7LAxNx8NO','2021-08-20 06:17:51.366000','075','vtBU6MkAFjMjZ','JIujzT9QJaA3c'),('Ro8TNhrcfis25',_binary '','2021-08-20 18:30','QVcpnjRGUbcW7','2021-08-20 05:59:55.603000','072','vtBU6MkAFjMjZ','JIujzT9QJaA3c'),('rWvCxuByE3dK1',_binary '\0','몸만 오시면 됩니다','QVcpnjRGUbcW7','2021-08-20 06:00:27.181000','073','vtBU6MkAFjMjZ','JIujzT9QJaA3c'),('saF1jwazne1zq',_binary '\0','허락합니다','n7N3t3WF417Gi','2021-08-20 04:42:51.475000','073','W9kYunNrx8XLa','vtBU6MkAFjMjZ'),('SC46r5vM0DJ7b',_binary '\0','2021-08-20 04:30','R8AiGyMOzrNwz','2021-08-20 04:36:33.049000','072','W9kYunNrx8XLa','vtBU6MkAFjMjZ'),('SxVNVimuOBbsl',_binary '\0','허락합니다','n7N3t3WF417Gi','2021-08-20 04:42:51.475000','073','vtBU6MkAFjMjZ','W9kYunNrx8XLa'),('y1X9g8501cJZI',_binary '\0','몸만 오시면 됩니다','QVcpnjRGUbcW7','2021-08-20 06:00:27.181000','073','JIujzT9QJaA3c','vtBU6MkAFjMjZ');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  7:37:18
