-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: i5a507.p.ssafy.io    Database: solver
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `sub_category_code` varchar(255) NOT NULL,
  `sub_category_name` varchar(255) DEFAULT NULL,
  `use_yn` bit(1) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sub_category_code`),
  KEY `FK58iav4hw4kpgw51jvgtn5xy5j` (`code`),
  CONSTRAINT `FK58iav4hw4kpgw51jvgtn5xy5j` FOREIGN KEY (`code`) REFERENCES `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES ('900','국어',_binary '','090'),('901','수학',_binary '','090'),('902','영어',_binary '','090'),('903','사회',_binary '','090'),('904','과학',_binary '','090'),('905','한국사',_binary '','090'),('906','제2외국어',_binary '','090'),('910','문학',_binary '','091'),('911','역사',_binary '','091'),('912','언어',_binary '','091'),('913','철학',_binary '','091'),('920','법',_binary '','092'),('921','경제',_binary '','092'),('922','교육',_binary '','092'),('923','사회',_binary '','092'),('924','통계',_binary '','092'),('925','행정',_binary '','092'),('930','물리',_binary '','093'),('931','생명',_binary '','093'),('932','수학',_binary '','093'),('933','천문',_binary '','093'),('934','화학',_binary '','093'),('935','동/식물',_binary '','093'),('940','건축',_binary '','094'),('941','농업',_binary '','094'),('942','기계',_binary '','094'),('943','화학',_binary '','094'),('944','전기/전자',_binary '','094'),('945','토목/환경',_binary '','094'),('946','컴퓨터/통신',_binary '','094'),('950','미술',_binary '','095'),('951','음악',_binary '','095'),('952','사진/영상',_binary '','095'),('953','스포츠/건강',_binary '','095'),('954','공연/매체예술',_binary '','095'),('960','기타',_binary '','096');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  7:37:15
