-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: i5a507.p.ssafy.io    Database: solver
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `evaluation`
--

DROP TABLE IF EXISTS `evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluation` (
  `id` varchar(255) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `score` int NOT NULL,
  `answer_id` varchar(255) DEFAULT NULL,
  `answer_user_id` varchar(255) DEFAULT NULL,
  `question_user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKry383rlfvg06roxajd8tot079` (`answer_id`),
  KEY `FKvax3gchehuk1pmspajy0l0kx` (`answer_user_id`),
  KEY `FKgydg9nys4k1w4e1brnr5kw4rn` (`question_user_id`),
  CONSTRAINT `FKgydg9nys4k1w4e1brnr5kw4rn` FOREIGN KEY (`question_user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKry383rlfvg06roxajd8tot079` FOREIGN KEY (`answer_id`) REFERENCES `answer` (`id`),
  CONSTRAINT `FKvax3gchehuk1pmspajy0l0kx` FOREIGN KEY (`answer_user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation`
--

LOCK TABLES `evaluation` WRITE;
/*!40000 ALTER TABLE `evaluation` DISABLE KEYS */;
INSERT INTO `evaluation` VALUES ('0cQjOdvttD4FX','흠...먼저 퇴장하셔서 조금 속상했어요',8,NULL,'vtBU6MkAFjMjZ','W9kYunNrx8XLa'),('aVgFZuw4w3gG8','최고에요!!! 또 받고싶어요!!!',10,NULL,'vtBU6MkAFjMjZ','JIujzT9QJaA3c'),('NLlycRdIkWFjr','명강의 였습니다',9,NULL,'JIujzT9QJaA3c','vtBU6MkAFjMjZ'),('S65JsD8wwiq5y','최고에요',9,NULL,'vtBU6MkAFjMjZ','JIujzT9QJaA3c'),('ZM7DdyavHkrfE','',10,NULL,'JIujzT9QJaA3c','vtBU6MkAFjMjZ');
/*!40000 ALTER TABLE `evaluation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  7:37:14
