-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: i5a507.p.ssafy.io    Database: solver
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `point_code`
--

DROP TABLE IF EXISTS `point_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `point_code` (
  `point_code` varchar(255) NOT NULL,
  `point_name` varchar(255) DEFAULT NULL,
  `user_yn` bit(1) NOT NULL,
  `value` int NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`point_code`),
  KEY `FK48091wqqqdh1q8ctgp2lr5oan` (`code`),
  CONSTRAINT `FK48091wqqqdh1q8ctgp2lr5oan` FOREIGN KEY (`code`) REFERENCES `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `point_code`
--

LOCK TABLES `point_code` WRITE;
/*!40000 ALTER TABLE `point_code` DISABLE KEYS */;
INSERT INTO `point_code` VALUES ('000','텍스트 답변 등록',_binary '',30,'080'),('001','화상 답변 등록',_binary '',50,'080'),('002','첫 답변',_binary '',50,'080'),('003','만료 12시간 이내 답변',_binary '',50,'080'),('004','텍스트 답변 채택',_binary '',100,'080'),('005','화상 답변 채택',_binary '',200,'080'),('006','질문 추천',_binary '',10,'080'),('007','답변 추천',_binary '',10,'080'),('008','질문 북마크 등록',_binary '',10,'080'),('100','질문 신고',_binary '',100,'081'),('101','답변 신고',_binary '',100,'081'),('102','댓글 신고',_binary '',100,'081'),('103','1일 홍보',_binary '',100,'081'),('104','2일 홍보',_binary '',200,'081'),('105','3일 홍보',_binary '',300,'081'),('106','4일 홍보',_binary '',100,'081'),('107','5일 홍보',_binary '',200,'081'),('108','6일 홍보',_binary '',300,'081'),('109','7일 홍보',_binary '',700,'081');
/*!40000 ALTER TABLE `point_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-20  7:37:13
